from django.apps import AppConfig


class CorduroyserverConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'corduroyserver'
